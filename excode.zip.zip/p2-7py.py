import random

# 어휘 리스트 (랜덤 선택용)
word_list = ["banana", "apple", "orange", "bug", "update"]

while True:
    # 어휘 리스트에서 단어를 랜덤하게 선택
    secret_word = random.choice(word_list)
    word_length = len(secret_word)

    # 단어의 글자수만큼 밑줄(_)로 구성된 리스트 생성
    guessed_display = ["_"] * word_length

    # 제한 횟수 설정 (예: 글자 수 또는 고정 횟수, 여기서는 6번으로 설정)
    trials_left = 6

    print("\n" + "=" * 40)
    print("행맨 게임을 시작합니다!")
    print(f"정답 단어: {' '.join(guessed_display)}")
    print(f"남은 횟수: {trials_left}번")
    print("=" * 40)

    # 게임 진행 루프
    while trials_left > 0 and "_" in guessed_display:
        guess = input("\n글자를 입력하세요: ").lower()

        # 한 글자만 제대로 입력했는지 검사 (간단한 예외 처리)
        if len(guess) != 1 or not guess.isalpha():
            print("알파벳 한 글자만 입력해주세요.")
            continue

        # 이미 맞춘 글자이거나 중복 입력 방지
        if guess in guessed_display:
            print("이미 맞춘 글자입니다.")
            continue

        # 글자가 단어에 포함되어 있는지 확인
        if guess in secret_word:
            print(f"'{guess}'가 단어에 포함되어 있습니다.")
            # 해당 글자가 있는 모든 위치를 찾아 밑줄을 해당 글자로 변경
            for idx in range(word_length):
                if secret_word[idx] == guess:
                    guessed_display[idx] = guess
        else:
            # 단어에 없으면 기회 차감
            trials_left -= 1
            print(f"땡! {trials_left} 번 남았습니다.")

        # 현재 맞추고 있는 상태 출력
        print("현재 상태:", " ".join(guessed_display))

    # 게임 결과 판정
    if "_" not in guessed_display:
        print("\n단어를 모두 맞혔습니다!")
    else:
        print(f"\n기회를 모두 소진했습니다. 정답은 '{secret_word}'입니다")

    # 옵션 추가: 사용자에게 게임을 계속할 것인지 선택하기
    play_again = input("\n게임을 다시 하겠습니까? (y/n): ").lower()
    if play_again != 'y':
        print("행맨 게임을 종료합니다.")
        break