# 입력
num1 = int(input("첫 번째 정수를 입력하세요: "))
num2 = int(input("두 번째 정수를 입력하세요: "))

# 출력
print(f"{num1} + {num2} = {num1 + num2}")
print(f"{num1} - {num2} = {num1 - num2}")
print(f"{num1} x {num2} = {num1 * num2}")
print(f"{num1} / {num2} = {num1 / num2}")

# 입력
num1 = int(input("첫 번째 정수를 입력하세요: "))
num2 = int(input("두 번째 정수를 입력하세요: "))

# 출력(format 사용)
print("{} + {} = {}".format(num1, num2, num1 + num2))
print("{} - {} = {}".format(num1, num2, num1 - num2))
print("{} x {} = {}".format(num1, num2, num1 * num2))
print("{} / {} = {}".format(num1, num2, num1 / num2))

# 입력
num1, num2 = map(int, input("두 정수를 공백으로 구분하여 입력하세요: ").split())

# 출력
print(f"{num1} + {num2} = {num1 + num2}")
print(f"{num1} - {num2} = {num1 - num2}")
print(f"{num1} x {num2} = {num1 * num2}")
print(f"{num1} / {num2} = {num1 / num2}")

# 입력
num1, num2 = map(int, input("두 정수를 공백으로 구분하여 입력하세요: ").split())

# 출력(format 사용)
print("{} + {} = {}".format(num1, num2, num1 + num2))
print("{} - {} = {}".format(num1, num2, num1 - num2))
print("{} x {} = {}".format(num1, num2, num1 * num2))
print("{} / {} = {}".format(num1, num2, num1 / num2))