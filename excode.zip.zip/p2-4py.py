# 1부터 100 사이의 자연수 n에 대하여 배수 판별
for n in range(1, 101):
    if n % 3 == 0 and n % 5 == 0:
        print(f"{n}은 3과 5의 배수입니다")
    elif n % 3 == 0:
        print(f"{n}은 3의 배수입니다")
    elif n % 5 == 0:
        print(f"{n}은 5의 배수입니다")