# 1과 100 사이의 자연수 n에 대하여 소수 판별
for n in range(2, 101):
    is_prime = True
    for i in range(2, n):# 2부터 n-1까지의 수로 나눠 떨어지는지확인
        if n % i == 0:
            is_prime = False  # 나눠 떨어지면 소수가 아님
            break  # 더 확인할 필요가 없으면 탈출
    if is_prime:
        print(f"{n}은 소수입니다")#소수일때 출력