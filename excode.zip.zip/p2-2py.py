# 명단 작성
student_dict = {}
print("--- 학생 명단 작성 ---")
print("학번에 '0'을 입력하거나, 이름에 'None'을 입력하면 입력을 종료합니다.\n")

while True:
    student_id = input("학번 입력: ") # 학번이 '0'이거나 이름에 'None'을 입력하면 반복 종료
    student_name = input("이름 입력: ")

    if student_id == '0' or student_name == 'None':
        break

    student_dict[student_id] = student_name

print("\n[생성된 학생 딕셔너리]")
print(student_dict)
print("-" * 30)

# 학번으로 이름 출력하기 및 종료 기능
while True:
    search_id = input("\n조회할 학번을 입력하세요 ('quit' 입력 시 종료): ")

    # 3. 'quit' 입력 시 종료
    if search_id == 'quit':
        print("프로그램을 종료합니다.")
        break

    # 2. 학번으로 이름 찾기
    if search_id in student_dict:
        print(f"학번 {search_id}의 이름: {student_dict[search_id]}")
    else:
        print("not found!")# 딕셔너리에 해당 학번(key)이 존재하면 이름(value) 출력, 없으면 "not found!" 출력