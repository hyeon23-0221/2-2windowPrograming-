import math
#a=3, b=4, c=5 일 때 식의 값 (1 / (1 + ab + c)
a, b, c = 3, 4, 5
result_1 = 1 / (1 + a * b + c)
print(f"1번 결과: {result_1}")

#2차방정식 계수 a=1, b=1, c=-6 일 때 두 근 (근의 공식 사용)
a, b, c = 1, 1, -6
discriminant = b**2 - 4 * a * c  # 판별식
root1 = (-b + math.sqrt(discriminant)) / (2 * a)
root2 = (-b - math.sqrt(discriminant)) / (2 * a)
print(f"2번 결과 (두 근): {root1} 또는 {root2}")

#원의 반지름 r=5 일 때 원의 면적
r = 5
area = math.pi * (r**2)
print(f"3번 결과 (원의 면적): {area}")

#beta = 2.0, g = 3.2일 때 beta * e^(-g)의 값
beta = 2.0
g = 3.2
result_4 = beta * math.exp(-g)
print(f"4번 결과: {result_4}")

# x=0, mu=1.5, rho=2.0 일 때 식의 값
x = 0
mu = 1.5
rho = 2.0
result_5 = (1 / (rho * math.sqrt(2 * math.pi))) * math.exp(
    -0.5 * ((x - mu) / rho) ** 2
)
print(f"5번 결과 (예시 식): {result_5}")