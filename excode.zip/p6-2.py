import math
import turtle

import figure  # figure.py 모듈을 import


# figure 모듈의 Polygon을 상속하여 정삼각형 클래스 “Triangle” 정의
class Triangle(figure.Polygon):
    # 객체가 몇 번째 생성된 것인지 추적하기 위한 클래스 변수
    instance_count = 0

    def __init__(self, sideLen):
        # 정삼각형은 변의 개수가 3개이므로 슈퍼 클래스(Polygon)에 3을 전달
        super().__init__(3)
        self.setSideLen(sideLen)

        # 인스턴스 생성 시 카운트를 증가시키고 serial 번호 부여
        Triangle.instance_count += 1
        self.serial = Triangle.instance_count

    # 삼각형의 면적을 구하여 표시하는 getArea() 메서드 오버라이드
    def getArea(self):
        # 정삼각형 면적 공식: (sqrt(3) / 4) * (변의 길이)^2
        return (math.sqrt(3) / 4) * (self.sideLen ** 2)

    # 객체가 몇 번째 생성된 것인지 알려주는 getSerial() 메서드 추가
    def getSerial(self):
        return self.serial

    # 삼각형을 그리는 draw() 메서드 추가
    def draw(self):
        for step in range(self.sideNumber):
            turtle.forward(self.sideLen)
            turtle.right(360 / self.sideNumber)
        # input("Press any key to stop")
        turtle.done()

if __name__ == "__main__":
    # 한 변의 길이가 300인 정삼각형 객체 생성
    tri = Triangle(300)

    # 1. 한 변의 길이가 300인 정삼각형의 면적을 구하여 출력
    print(f"한 변의 길이가 {tri.sideLen}인 정삼각형의 면적: {tri.getArea():.2f}")

    # 2. 생성된 인스턴스가 몇 번째 객체인지 출력
    print(f"생성된 인스턴스가 몇 번째 객체인지: {tri.getSerial()}번째 객체")

    # 3. 이 삼각형을 그리시오 (터틀 그래픽 실행)
    print("삼각형을 그립니다... (창을 닫으려면 콘솔창에서 엔터를 누르세요)")
    tri.draw()