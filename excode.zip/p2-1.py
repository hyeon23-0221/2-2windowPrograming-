# [문제 2-1] 리스트 연습: 두 리스트의 대응하는 원소 곱의 합 구하기

# 리터럴 방식으로 3개의 정수를 가진 두 리스트 생성
list1 = [1, 0, 1]
list2 = [1, 1, 2]

# 각 원소들을 곱한 후 모두 더하기
result = list1[0] * list2[0] + list1[1] * list2[1] + list1[2] * list2[2]

# 결과 출력
print(f"{list1}* {list2} = {result}")