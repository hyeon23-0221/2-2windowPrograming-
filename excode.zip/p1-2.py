#결과 10, 10
x = 10
def test():
    print(x)
test()
print(x)

#결과 20, 10
x = 10
def test():
    x = 20
    print(x)
print(x)
test()
print(x)

#결과 A: 30, B: 20, C: 10
x = 10
def outer():
    x = 20
    def inner():
        x = 30
        print("A:", x)
    inner()
    print("B:", x)
outer()
print("C:", x)

#결과 10, 20, C: 20

x = 10
def test():
    global x
    print(x)
    x = 20
test()
print(x)
print("C:", x)
