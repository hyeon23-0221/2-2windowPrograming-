# min_max 함수 정의
def min_max(numbers):
    if not numbers:
        return (None, None)  # 빈 리스트인 경우 예외 처리

    min_val = min(numbers)
    max_val = max(numbers)

    return (min_val, max_val)

# 사용자한테 정수들을 입력받아서 테스트하는 프로그램
if __name__ == "__main__":
    print("최소값과 최대값 찾기 프로그램")
    user_input = input("정수들을 공백으로 구분하여 입력하세요: ")

    # 입력받은 문자열을 공백 기준으로 쪼개서 정수 리스트로 변환
    num_list = [int(x) for x in user_input.split()]

    # min_max 함수 호출
    result = min_max(num_list)

    # 결과 출력
    print(f"입력된 리스트: {num_list}")
    print(f"최소값과 최대값 (튜플 반환): {result}")
    print(f"min: {result[0]}, max: {result[1]}")