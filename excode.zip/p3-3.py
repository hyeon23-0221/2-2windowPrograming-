# count_vowel 함수 정의
def count_vowel(text):
    vowels = "aeiouAEIOU"  # 대소문자 모음 정의
    count = 0
    for char in text:
        if char in vowels:
            count += 1
    return count
# 사용자로부터 문자열을 입력받아 테스트하는 프로그램
if __name__ == "__main__":
    print("문자열 모음 개수 세기 프로그램")
    user_input = input("문자열을 입력하세요: ")

    # count_vowel 함수 호출
    vowel_count = count_vowel(user_input)

    # 결과 출력
    print(f"입력한 문자열: '{user_input}'")
    print(f"모음의 개수: {vowel_count}개")