# input()을 두 번 사용하는 방식 + f-string
# 입력: 정수를 각각 개별 입력받음
num1 = int(input("첫 번째 정수를 입력하세요: "))
num2 = int(input("두 번째 정수를 입력하세요: "))

# 출력: f-string 활용
print(f"{num1} + {num2} = {num1 + num2}")
print(f"{num1} - {num2} = {num1 - num2}")
print(f"{num1} x {num2} = {num1 * num2}")
print(f"{num1} / {num2} = {num1 / num2}")

print("-" * 30)

# input()을 두 번 사용하는 방식 + format()
# 입력: 정수를 각각 개별 입력받음
num1 = int(input("첫 번째 정수를 입력하세요: "))
num2 = int(input("두 번째 정수를 입력하세요: "))

# 출력: format 메서드 활용
print("{} + {} = {}".format(num1, num2, num1 + num2))
print("{} - {} = {}".format(num1, num2, num1 - num2))
print("{} x {} = {}".format(num1, num2, num1 * num2))
print("{} / {} = {}".format(num1, num2, num1 / num2))

print("-" * 30)

# input()을 한 번 사용하는 방식 + f-string
# 입력: 공백을 기준으로 두 정수를 한 번에 입력받음
num1, num2 = map(int, input("두 정수를 공백으로 구분하여 입력하세요: ").split())

# 출력: f-string 활용
print(f"{num1} + {num2} = {num1 + num2}")
print(f"{num1} - {num2} = {num1 - num2}")
print(f"{num1} x {num2} = {num1 * num2}")
print(f"{num1} / {num2} = {num1 / num2}")

print("-" * 30)

# input()을 한 번 사용하는 방식 + format()
# 입력: 공백을 기준으로 두 정수를 한 번에 입력받음
num1, num2 = map(int, input("두 정수를 공백으로 구분하여 입력하세요: ").split())

# 출력: format 메서드 활용
print("{} + {} = {}".format(num1, num2, num1 + num2))
print("{} - {} = {}".format(num1, num2, num1 - num2))
print("{} x {} = {}".format(num1, num2, num1 * num2))
print("{} / {} = {}".format(num1, num2, num1 / num2))