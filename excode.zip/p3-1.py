def calc(*args, op='+'):
    # 인수가 없을 경우의 기본값 처리
    if not args:
        return 0 if op == '+' else 1
    if op == '+':
        result = 0
        for num in args:
            result += num
        return result
    elif op == '*':
        result = 1
        for num in args:
            result *= num
        return result
    else:
        return "지원하지 않는 연산자입니다. ('+' 또는 '*')"

# 1 + 1 + 4 = 6
result1 = calc(1, 1, 4, op='+')
print(f"calc(1, 1, 4, op='+') -> 반환값 {result1}")

# 1 * 2 = 2
result2 = calc(1, 2, op='*')
print(f"calc(1, 2, op='*') -> 반환값 {result2}")
