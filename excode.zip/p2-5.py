# 4년마다 한 번씩 하루를 추가하되, 100년마다 한 번은 건너뛰고, 400년마다 다시 추가하는 해
year = int(input("년도를 입력하세요: "))

if (year % 4 == 0 and year % 100 != 0) or (year % 400 == 0):
    print(f"{year}년은윤년입니다")
else:
    print(f"{year}년은윤년이아닙니다")