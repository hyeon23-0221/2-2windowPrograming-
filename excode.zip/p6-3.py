import figure

# getArea()를 정상적으로 구현한 클래스들은 객체 생성이 잘 되는지 확인
print("--- 정상적인 클래스(Rectangle, Triangle) 객체 생성 테스트 ---")
rect = figure.Rectangle()
rect.setSideLen(10)
print(f"Rectangle 면적: {rect.getArea()}")

tri = figure.Triangle(300)
print(f"Triangle 면적: {tri.getArea():.2f}")

print("\n--- 추상 메서드를 구현하지 않은 자식 클래스 테스트 ---")


# getArea()를 일부러 구현하지 않은 자식 클래스 정의
class IncompletePolygon(figure.Polygon):
    def __init__(self):
        super().__init__(5)  # 5각형 설정

    # getArea() 메서드를 구현하지 않음!


# 객체 생성 시 TypeError가 발생하는지 확인
try:
    print("IncompletePolygon 객체 생성을 시도합니다...")
    bad_obj = IncompletePolygon()  # 이 시점에서 에러 발생
    print("객체 생성 성공?! (에러가 나야 정상입니다)")
except TypeError as e:
    print("[확인 완료] 추상 메서드를 구현하지 않아 객체 생성 불가!")
    print(f"발생한 에러 메시지: {e}")
