class Calc:
    # 클래스 변수: 생성된 인스턴스의 개수를 추적하기 위한 카운터
    instance_count = 0

    def __init__(self, a, b):
        self.a = a
        self.b = b

        # 인스턴스가 생성될 때마다 카운터를 1 증가시키고 고유 시리얼 번호 부여
        Calc.instance_count += 1
        self.serial = Calc.instance_count

    # 두 정수의 합을 계산하여 반환
    def add(self):
        return self.a + self.b

    # 두 정수의 차를 계산하여 반환
    def sub(self):
        return self.a - self.b

    # 객체가 몇 번째로 생성된 인스턴스인지 반환
    def getSerial(self):
        return self.serial

a = 3
b = 2
calc1 = Calc(a, b)

print(f"{a} + {b} = {calc1.add()}")     # '3 + 2 = 5' 출력
print(f"{a} - {b} = {calc1.sub()}")     # '3 - 2 = 1' 출력 (구문 오류 수정 완료)

calc2 = Calc(3, 4)
print(f"3 + 4 = {calc2.add()}")         # '3 + 4 = 7' 출력
print(f"3 - 4 = {calc2.sub()}")         # '3 - 4 = -1' 출력 (구문 오류 수정 완료)

print(f"Serial of calc1: {calc1.getSerial()}")  # 1 출력
print(f"Serial of calc2: {calc2.getSerial()}")  # 2 출력