# 함수 func와 두 개의 숫자(x, y)를 인수로 받아 결과를 반환하는 고차 함수 do_operation 작성
def do_operation(func, x, y):
    return func(x, y)

# 테스트를 위한 일반 함수 정의 (add, sub)
def add(a, b):
    return a + b

def sub(a, b):
    return a - b

print("--- 1. 일반 함수(add, sub)를 이용한 테스트 ---")
result_add = do_operation(add, 2, 3)
print(f"do_operation(add, 2, 3) -> {result_add}")  # 출력: 5

result_sub = do_operation(sub, 5, 2)
print(f"do_operation(sub, 5, 2) -> {result_sub}")  # 출력: 3


print("\n--- 2. lambda 함수를 이용한 테스트 ---")
# add와 sub 기능을 람다(lambda) 함수로 정의
add_lambda = lambda a, b: a + b
sub_lambda = lambda a, b: a - b

# 람다 함수를 고차 함수에 전달하여 테스트
result_lambda_add = do_operation(add_lambda, 10, 5)
print(f"do_operation(add_lambda, 10, 5) -> {result_lambda_add}")  # 출력: 15

result_lambda_sub = do_operation(sub_lambda, 10, 5)
print(f"do_operation(sub_lambda, 10, 5) -> {result_lambda_sub}")  # 출력: 5

# 익명 람다 함수를 직접 인수로 전달하는 방식
result_direct = do_operation(lambda a, b: a * b, 4, 3)
print(f"do_operation(lambda 곱셈, 4, 3) -> {result_direct}")  # 출력: 12