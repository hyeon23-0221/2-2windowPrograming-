def process_file():
    while True:
        # 사용자로부터 파일명 입력받기
        filename = input("\n가져올 파일명을 입력하세요 (종료하려면 'quit' 입력): ")

        if filename.lower() == 'quit':
            print("프로그램을 종료합니다.")
            break

        try:
            # 파일 열기
            with open(filename, 'r', encoding='utf-8') as file:
                lines = file.readlines()

            # 새로운 저장 파일명 생성
            if '.' in filename:
                base_name = filename.rsplit('.', 1)[0]
                save_filename = f"{base_name}.sav"
            else:
                save_filename = f"{filename}.sav"

            # 라인 번호를 붙여서 출력 및 저장 파일에 기록
            print(f"\n[{filename}] 파일 내용 (라인 번호 추가)")

            with open(save_filename, 'w', encoding='utf-8') as save_file:
                for idx, line in enumerate(lines, start=1):
                    # 줄바꿈 문자가 중복으로 들어가지 않도록 strip() 처리 후 포맷팅
                    formatted_line = f"{idx} {line.strip()}\n"
                    print(formatted_line, end='')  # 화면 출력
                    save_file.write(formatted_line)  # 파일에 저장

            print(f"\n성공적으로 '{save_filename}' 파일로 저장되었습니다!")
            break  # 정상 처리 완료 시 루프 탈출

        except FileNotFoundError:
            # 파일이 없는 경우 예외 처리
            print(f"오류: '{filename}'해당 파일을 찾을 수 없습니다. 올바른 파일명으로 다시 입력해 주세요.")
        except Exception as e:
            # 기타 예외 처리
            print(f"예기치 못한 오류가 발생했습니다: {e}")

# 프로그램 실행
if __name__ == "__main__":
    process_file()