# 인수를 받는 데코레이터 정의
def deco2_add(type):
    def decorator(func):
        def wrapper(a, b):
            result = func(a, b)  # 원래 함수의 연산 결과(예: 6, 3)를 가져옴

            # type 인수에 따른 문자열 포맷팅 분기 처리
            if type == "math":
                return f"{a} + {b} = {result}"
            elif type == "word":
                return f"The sum of {a} and {b} is {result}"  # 원문 예시 대소문자 규격 반영

        return wrapper

    return decorator


# type = "math" 적용 테스트
@deco2_add(type="math")
def add_math(a, b):
    return a + b


print(add_math(2, 4))  # 출력 결과


# type = "word" 적용 테스트
@deco2_add(type="word")
def add_word(a, b):
    return a + b


print(add_word(1, 2))  # 출력 결과