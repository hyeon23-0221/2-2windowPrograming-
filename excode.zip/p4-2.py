def analyze_file():
    while True:
        # 사용자로부터 파일명 입력받기
        filename = input("\n분석할 파일명을 입력하세요 (종료하려면 'quit' 입력): ")

        if filename.lower() == 'quit':
            print("프로그램을 종료합니다.")
            break

        try:
            # 파일 열기 및 내용 읽기 (FileNotFoundError 예외 처리)
            with open(filename, 'r', encoding='utf-8') as file:
                lines = file.readlines()

            # 전체 텍스트 내용 합치기
            full_text = "".join(lines)

            # 통계 계산
            num_lines = len(lines)

            # 단어 수: 공백(스페이스, 탭, 줄바꿈 등)을 기준으로 분리한 리스트의 길이
            words = full_text.split()
            num_words = len(words)

            # 공백을 제외한 글자 수: 전체 텍스트에서 공백 문자(' ', '\t', '\n', '\r')들을 모두 제거한 후 길이 계산
            # 또는 각 단어들의 길이를 모두 합산하거나, replace를 사용할 수 있습니다.
            non_space_chars = len(full_text.replace(" ", "").replace("\n", "").replace("\t", "").replace("\r", ""))

            # 지정된 형식에 맞추어 출력
            print(f"characters : {non_space_chars}")
            print(f"words      : {num_words}")
            print(f"lines      : {num_lines}")

            break  # 정상 처리 완료 후 루프 탈출

        except FileNotFoundError:
            # 파일이 없을 경우 예외 처리
            print(f"오류: '{filename}' 파일을 찾을 수 없습니다. 올바른 파일명을 다시 입력해 주세요.")
        except Exception as e:
            print(f"예기치 못한 오류가 발생했습니다: {e}")

# 프로그램 실행
if __name__ == "__main__":
    analyze_file()