student_dict = {}
print("--- 학생 명단 작성 ---")
print("학번에 '0'을 입력하거나, 이름에 'None'을 입력하면 입력을 종료합니다.\n")

# 명단 작성 루프
while True:
    student_id = input("학번 입력: ")
    # 학번에 '0'을 입력하면 이름 입력 단계로 넘어가지 않고 즉시 종료
    if student_id == '0':
        break

    student_name = input("이름 입력: ")
    # 이름에 'None'을 입력하면 종료
    if student_name == 'None':
        break

    # 딕셔너리에 id: name 아이템 추가
    student_dict[student_id] = student_name

print("\n[생성된 학생 딕셔너리]")
print(student_dict)
print("-" * 30)  # 구문 오류가 있던 출력선 수정 완료

# 학번으로 이름 출력하기 및 종료 기능
while True:
    search_id = input("\n조회할 학번을 입력하세요 ('quit' 입력 시 종료): ")

    # 'quit' 입력 시 프로그램 종료
    if search_id == 'quit':
        print("프로그램을 종료합니다.")
        break

    # 학번으로 이름 찾기 및 결과 출력
    if search_id in student_dict:
        print(f"학번 {search_id}의 이름: {student_dict[search_id]}")
    else:
        print("not found!")  # 딕셔너리에 학번이 없을 경우 출력